//
//  PlantCollection.swift
//  PaudhaUI
//
//  Created by user1 on 19/02/24.
//

import SwiftUI


class PlantCollection: ObservableObject {
    @Published var plants: [Plant] = []
    
}

