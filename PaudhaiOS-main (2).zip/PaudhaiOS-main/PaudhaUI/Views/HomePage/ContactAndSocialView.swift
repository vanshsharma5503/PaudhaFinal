//
//  ContactAndSocialView.swift
//  PaudhaUI
//
//  Created by user1 on 19/02/24.
//

import SwiftUI

struct ContactAndSocialView: View {
    var body: some View {
        Text("Contact & Social View")
    }
}
