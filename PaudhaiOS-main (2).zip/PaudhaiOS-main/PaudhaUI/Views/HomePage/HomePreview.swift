//
//  HomePreview.swift
//  PaudhaUI
//
//  Created by user1 on 19/02/24.
//

import SwiftUI


struct Home_Previews: PreviewProvider {
    static var previews: some View {
        Home()
    }
}
