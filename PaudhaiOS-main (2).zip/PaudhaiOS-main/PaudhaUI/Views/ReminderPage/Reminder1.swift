//
//  Reminder1.swift
//  PaudhaUI
//
//  Created by Anant Narain on 16/01/24.
//

//
//  Reminder1.swift
//  Paudha
//
//  Created by user 1 an on 18/12/23.
//
import SwiftUI
struct ContentViewRem_Previews: PreviewProvider {
    static var previews: some View {
        RemindersView()
    }
}

